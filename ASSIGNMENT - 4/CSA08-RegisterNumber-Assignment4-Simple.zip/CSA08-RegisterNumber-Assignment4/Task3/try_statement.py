# Task 3.3 and 3.4 - complete try statement, raise ... from, and the misuse experiment
from datetime import datetime


class InvalidRecord(Exception):
    pass


def check_date(text):
    try:
        datetime.strptime(text, "%Y-%m-%d")
    except ValueError as e:
        raise InvalidRecord("bad date " + text) from e      # keeps the original cause


def read_file(path):
    f = None
    try:
        f = open(path, "r", encoding="utf-8")
        lines = f.readlines()
    except FileNotFoundError:
        print("  file not found")
    except PermissionError:
        print("  permission denied")
    except UnicodeDecodeError:
        print("  wrong encoding")
    else:
        print("  read", len(lines), "lines")          # only when no error happened
    finally:
        if f is not None:
            f.close()
        print("  finished (finally always runs)")


print("missing file:")
read_file("nothing.txt")
open("empty.txt", "w").close()
print("empty file:")
read_file("empty.txt")

try:
    check_date("2026-13-45")
except InvalidRecord as e:
    print("Error:", e, "| original cause:", type(e.__cause__).__name__)

# misuse experiment: 'except Exception: pass' hides a typing error
count = 0
for status in ["P", "A", "P"]:
    try:
        if status == "P":
            count = cuont + 1          # typing error (cuont)
    except Exception:
        pass
print("Misuse: count should be 2 but is", count, "- no error was shown")
