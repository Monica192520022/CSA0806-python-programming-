import os
import tempfile


class InvalidRecord(Exception):
    """Raised when a line of the attendance file is not in the expected format."""


def parse_line(line):
    """'192311001,2026-10-08,P' -> ('192311001', '2026-10-08', 'P')"""
    parts = line.strip().split(",")
    # TODO 1
    if len(parts) != 3:
        raise InvalidRecord("expected 3 fields, found " + str(len(parts)))
    if parts[2] not in ("P", "A"):
        raise InvalidRecord("invalid status '" + parts[2] + "'")
    return (parts[0], parts[1], parts[2])


def summarise(path):
    present, absent, errors = 0, 0, []
    # TODO 2
    try:
        with open(path, "r", encoding="utf-8") as f:
            for number, line in enumerate(f, start=1):
                try:
                    reg, date, status = parse_line(line)
                except InvalidRecord as e:
                    errors.append((number, str(e)))
                else:
                    if status == "P":
                        present += 1
                    else:
                        absent += 1
    except FileNotFoundError:
        errors.append((0, "file not found: " + str(path)))
    return present, absent, errors


data = ("192311001,2026-10-08,P\n192311002,2026-10-08,A\n"
        "192311003,2026-10-08\n192311004,2026-10-08,L\n")
with tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False,
                                 encoding="utf-8") as tmp:
    tmp.write(data)
print(summarise(tmp.name))
os.remove(tmp.name)
print(summarise("no_such_file.csv"))      # missing file test
