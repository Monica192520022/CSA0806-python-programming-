# Task 2 - monthly attendance: read every file ONCE, count in dictionaries
import os

present = {}
total = {}
damaged = []

for name in sorted(os.listdir("data")):
    if not name.endswith(".txt"):
        continue
    with open(os.path.join("data", name), "r", encoding="utf-8") as f:
        for number, line in enumerate(f, start=1):
            parts = line.strip().split(",")
            if len(parts) != 3:
                damaged.append(name + " line " + str(number) + ": missing fields -> " + line.strip())
                continue
            reg, date, status = parts
            if status not in ("P", "A"):
                damaged.append(name + " line " + str(number) + ": wrong status -> " + line.strip())
                continue
            total[reg] = total.get(reg, 0) + 1
            if status == "P":
                present[reg] = present.get(reg, 0) + 1

with open("report.txt", "w", encoding="utf-8") as out:
    for reg in sorted(total):
        percent = round(100 * present.get(reg, 0) / total[reg], 1)
        flag = "  BELOW 75%" if percent < 75 else ""
        out.write(reg + " " + str(percent) + flag + "\n")

with open("damaged.log", "w", encoding="utf-8") as log:
    for d in damaged:
        log.write(d + "\n")

print(open("report.txt").read())
print(open("damaged.log").read())
