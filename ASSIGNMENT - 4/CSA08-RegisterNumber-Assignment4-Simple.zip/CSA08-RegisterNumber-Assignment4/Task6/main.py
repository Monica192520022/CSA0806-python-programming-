from fest.process import run

files = ["inputs/cse.txt", "inputs/ece.txt", "inputs/mech.txt", "inputs/it.txt"]   # it.txt is missing
seen, by_event, errors = run(files, "output")
print("Unique students:", len(seen))
print("Participants:", {ev: len(v) for ev, v in sorted(by_event.items())})
print("Errors:")
for e in errors:
    print(" ", e)
