# Alternative: find duplicates by searching a list (slow) instead of a set (fast)
import time
for n in (2000, 10000, 20000):
    regs = [str(i % (n * 9 // 10)) for i in range(n)]
    start = time.time(); seen = []
    for r in regs:
        if r not in seen:
            seen.append(r)
    t1 = time.time() - start
    start = time.time(); seen = set()
    for r in regs:
        if r not in seen:
            seen.add(r)
    t2 = time.time() - start
    print("n =", n, "list:", round(t1, 4), "s  set:", round(t2, 5), "s")
