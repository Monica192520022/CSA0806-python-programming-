class InvalidRegistration(Exception):
    """Raised for a damaged or invalid line."""


def valid_email(email):
    if email == "" or " " in email:
        return False
    if email.count("@") != 1:
        return False
    local, domain = email.split("@")
    if local == "" or "." not in domain:
        return False
    if domain.startswith(".") or domain.endswith("."):
        return False
    return True


def check_line(line):
    parts = line.strip().split(",")
    if len(parts) != 5:
        raise InvalidRegistration("expected 5 fields, found " + str(len(parts)))
    reg, name, dept, email, events = parts
    if len(reg) != 9 or not reg.isdigit():
        raise InvalidRegistration("bad register number")
    if not valid_email(email):
        raise InvalidRegistration("invalid e-mail " + email)
    return reg, name, dept, email, [e.strip() for e in events.split(";") if e.strip() != ""]
