import os
from fest.checks import check_line, InvalidRegistration


def run(files, out_folder):
    os.makedirs(os.path.join(out_folder, "events"), exist_ok=True)
    seen = {}               # register number -> [name, dept, email, events]
    errors = []
    for path in files:
        try:
            with open(path, "r", encoding="utf-8") as f:
                lines = f.readlines()
        except FileNotFoundError:
            errors.append(path + ": file is missing")
            continue
        for number, line in enumerate(lines, start=1):
            if line.strip() == "":
                continue
            try:
                reg, name, dept, email, events = check_line(line)
            except InvalidRegistration as e:
                errors.append(path + " line " + str(number) + ": " + str(e))
                continue
            if reg in seen:                       # duplicate: merge the events
                for ev in events:
                    if ev not in seen[reg][3]:
                        seen[reg][3].append(ev)
                errors.append(path + " line " + str(number) + ": duplicate " + reg + " (events merged)")
            else:
                seen[reg] = [name, dept, email, events]

    by_event = {}
    for reg in seen:
        for ev in seen[reg][3]:
            by_event.setdefault(ev, []).append(reg + "," + seen[reg][0])

    with open(os.path.join(out_folder, "master_list.csv"), "w") as f:
        for reg in sorted(seen):
            f.write(reg + "," + ",".join(seen[reg][:3]) + "," + ";".join(seen[reg][3]) + "\n")
    for ev in by_event:
        with open(os.path.join(out_folder, "events", ev.lower() + ".txt"), "w") as f:
            f.write("\n".join(sorted(by_event[ev])) + "\n")
    with open(os.path.join(out_folder, "errors.log"), "w") as f:
        f.write("\n".join(errors) + "\n")
    with open(os.path.join(out_folder, "summary.txt"), "w") as f:
        f.write("Unique students: " + str(len(seen)) + "\n")
        for ev in sorted(by_event):
            f.write(ev + ": " + str(len(by_event[ev])) + "\n")
    return seen, by_event, errors
