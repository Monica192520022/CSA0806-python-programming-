# Task 1.2 - repaired script
from decimal import Decimal, InvalidOperation


def total_bills(filename):
    total = Decimal("0")
    report = []
    rejected = []
    with open(filename, "r", encoding="utf-8") as f:     # file closes by itself
        for number, line in enumerate(f, start=1):        # one line at a time
            line = line.strip()
            if line == "":
                continue
            parts = line.split(",")
            if len(parts) != 3:
                rejected.append((number, line, "wrong number of fields"))
                continue
            try:
                amount = Decimal(parts[2])
            except InvalidOperation:
                rejected.append((number, line, "amount is not a number"))
                continue
            if amount < 0:
                rejected.append((number, line, "negative amount"))
                continue
            total = total + amount
            report.append(parts[1] + " " + str(amount))
    return total, report, rejected


try:
    total, report, rejected = total_bills("mess_oct.txt")
except FileNotFoundError:
    print("File not found")
else:
    print("\n".join(report))
    print("Total", total)
    print("Rejected lines:")
    for item in rejected:
        print(" ", item)
