# Task 1 alternative: read the whole file at once, and compare memory with line-by-line
import tracemalloc

with open("big.txt", "w") as f:                      # make a file of 50,000 lines
    for i in range(50000):
        f.write("19231" + str(10000 + i) + ",Student" + str(i) + ",1250.50\n")


def line_by_line():
    count = 0
    with open("big.txt") as f:
        for line in f:
            count += 1
    return count


def whole_file():
    with open("big.txt") as f:
        lines = f.readlines()
    return len(lines)


for name, func in [("line by line", line_by_line), ("readlines()", whole_file)]:
    tracemalloc.start()
    func()
    peak = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    print(name, "peak memory:", round(peak / 1024), "KB")
import os
os.remove("big.txt")
