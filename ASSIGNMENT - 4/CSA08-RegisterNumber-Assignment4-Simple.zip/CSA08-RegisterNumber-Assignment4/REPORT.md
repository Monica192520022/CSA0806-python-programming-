# Assignment 4 (CO4) - Simple Report

Name: ________  Register number: ________  GitHub link: ________

Pseudocode style: START / END, INPUT / OUTPUT, SET, IF ... ENDIF, FOR EACH ... ENDFOR (check it against the SIMATS standard).

## Task 1 - Repair the mess-bill script
Evidence: the original script printed only Bala 1300, Farook -50 and Total 1250. The correct total is 4941.50.

Problems and what goes wrong:
1. Hard-coded path: works on one computer only.
2. File never closed: the file stays locked and handles pile up.
3. read() loads the whole file: memory grows with file size.
4. Bare except with pass: every error is hidden, no message.
5. int() for amounts: 1250.50 fails, the bill is silently left out (use Decimal).
6. report = report + ...: slow, copies the string each time (use a list and join).
7. Last empty line: becomes an error that is hidden.
8. No list of rejected lines: the office never knows who was missed.

Repair: repaired.py uses with, one line at a time, specific exceptions, a rejected list and a function with the file name as parameter.

Pseudocode:
    START total_bills(filename)
        SET total = 0, report = empty list, rejected = empty list
        OPEN filename using WITH
        FOR EACH line with number
            IF line is blank THEN skip ENDIF
            IF fields are not 3 THEN add to rejected; skip ENDIF
            IF amount is not a number or is negative THEN add to rejected; skip ENDIF
            SET total = total + amount
        ENDFOR
        OUTPUT total, report, rejected
    END

Defence (under 100 words): My version reads one line at a time, so 50,000 lines never sit in memory together. The with statement closes the file even after an error. Decimal keeps paise exact. Only expected problems are skipped, so real bugs still show. Every rejected line is saved with its number and reason, so no bill is lost silently. The file name is a parameter, so the function can be reused.

Alternative (read() or readlines()): time is O(n) in both. Memory: readlines() holds the whole file, O(file size); line by line holds one line, O(1). Measured for 50,000 lines: line by line 21 KB, readlines() 4,001 KB.

## Task 2 - Biometric attendance
- Input: lines like 192311001,2026-10-01,P in files day1.txt, day2.txt ... in a folder.
- Data structures: dictionaries present and total (register number to count) and a list damaged.
- Outputs: report.txt (percentage per student, BELOW 75% flag) and damaged.log (file name, line number, reason).
- File operations: r for the daily files, w for the reports (rebuilt every run), utf-8 encoding, reading by iterating over the file, write() with an explicit "\n", os.listdir to list the files.

Pseudocode:
    START
        SET present = {}, total = {}, damaged = []
        FOR EACH file in the folder
            FOR EACH line with number
                IF fields are not 3 OR status is not P or A THEN add to damaged; skip ENDIF
                total[reg] = total[reg] + 1
                IF status is P THEN present[reg] = present[reg] + 1 ENDIF
            ENDFOR
        ENDFOR
        FOR EACH reg: percent = 100 x present / total; WRITE; flag if below 75
        WRITE damaged log
    END

Trace of day2.txt (line 2 damaged): line 1 192311001 P -> total 2, present 2; line 2 "192311002,2026-10-02" has 2 fields -> logged as damaged, counts unchanged; line 3 192311003 A -> total +1.

Alternative (re-read all files for each student): time O(s x f x l) versus O(f x l) for one pass; space O(1) extra versus O(s). The one-pass method opens each file once.

## Task 3 - Error handling
| Failure | Exception |
| --- | --- |
| folder or file missing | FileNotFoundError |
| no permission | PermissionError |
| wrong encoding | UnicodeDecodeError |
| wrong number of fields | InvalidRecord (or IndexError / ValueError if unpacking) |
| wrong status letter | InvalidRecord |
| bad date | ValueError, converted with raise InvalidRecord from e |
| empty file | no exception, check the number of lines |

Custom exception: InvalidRecord is raised in parse_line() (it knows the rule) and handled in summarise() (it knows the file and line number and decides to log and continue).

Complete try statement (try_statement.py): try opens and reads; specific except clauses; else runs only when no error happened; finally always closes the file. raise ... from e keeps the original cause (output shows original cause: ValueError).

Misuse experiment: with except Exception: pass and the typing error cuont, the program printed count 0 (should be 2) and no error. NameError is a kind of Exception, so it is caught and pass does nothing. A specific except would have shown the NameError.

Complete the code output: (1, 1, [(3, 'expected 3 fields, found 2'), (4, "invalid status 'L'")]); a missing file gives (0, 0, [(0, 'file not found: no_such_file.csv')]).

Alternative (look before you leap with if checks): both styles are O(1) per line. When bad lines are rare the costs are about equal; when bad lines are common, raising exceptions is slower than an if check (in my earlier measurement about 0.6 microseconds against 0.11 microseconds per line when all lines were bad). Space is O(1) in both.

## Task 4 - Forensics
Defects: (1) mode w erases the file each time, so only the last day remains; (2) write() adds no newline, so titles are joined; (3) if write() fails, close() is never reached and the file stays open; (4) the error is not saved anywhere, and only FileNotFoundError is handled; (5) the input file is never closed.
Evidence: buggy.py printed 'ChemistryBiology' after three days, and a TypeError from write().
Repair: fixed.py uses mode a, "\n" after each book, with statements and errors.log; output shows all six books on separate lines and "missing file: day9.txt" in errors.log.
Rules: always use with; choose the mode on purpose (w replaces, a adds) and write the "\n" yourself; never hide errors.
Alternative (manual try/finally): same time O(n) and space O(1). With try/finally and with, 0 files stay open after an error. Without protection one file stays open per error.

## Task 5 - Four organisations
Run results are the same in all four: percentages 100.0, 0.0 and 20.0, and student 192311003 absent three days in a row.
| Organisation | Files changed for the new report |
| --- | --- |
| (a) one script | 1 |
| (b) one module + main | 2 |
| (c) three modules | 2 (stats.py, main.py) |
| (d) package | 2 (attendance/stats.py, main.py) |

| Criterion | (a) | (b) | (c) | (d) |
| --- | --- | --- | --- | --- |
| Readability | fine when small | good | each file has one job | best |
| Reuse | copy and paste | import module | import what you need | import anywhere |
| Testing | hard | easy | easier | easiest |
| Name conflicts | all in one space | one module name | short names may clash | package name separates names |

Imports: import attendance.stats needs the full name attendance.stats.percentage(); from attendance import stats gives the short name stats.percentage(); from attendance.stats import percentage gives just percentage() but may clash with your own names.
Alternative (one script): a package is imported once and cached in sys.modules, so the extra cost is tiny (microseconds, measured earlier 264 microseconds the first time and 0.6 microseconds the second). Memory is a few kilobytes. In a package you find a function by file name, in one script you search a long file.

## Task 6 - Fest registration desk
Stage 1: input is department files (reg, name, dept, e-mail, events with semicolons); output is master_list.csv, events/*.txt, summary.txt and errors.log. Rules: 9-digit register number, valid e-mail, one record per student, events merged for duplicates. Testable: duplicate appears once; invalid e-mail goes to errors.log; damaged line is logged and processing continues; missing file does not stop the program.

Stage 2 flow:
    department files -> read (missing file -> errors.log) -> each line -> validate (invalid -> errors.log)
    -> already in seen? (yes: merge events, log) (no: add) -> group by event -> master list, event files, summary, errors.log

Stage 3: duplicates by a dictionary of register numbers already seen (O(1) average lookup). E-mail checked with string methods: no spaces, exactly one @, non-empty local part, a dot inside the domain, not at its start or end. FileNotFoundError handled around reading a file; InvalidRegistration (custom) raised in checks.py and handled in process.py for each line.

Stage 4 package: fest/checks.py (InvalidRegistration, valid_email, check_line), fest/process.py (run), main.py.
    START run(files)
        FOR EACH file: TRY read; ON missing file log and continue
            FOR EACH line: TRY check_line; ON InvalidRegistration log and continue
                IF reg in seen THEN merge events ELSE add ENDIF
        group by event; write master list, event files, summary, errors.log
    END

Stage 5 output: Unique students 4; Dance 3, Drama 1, Quiz 3, Singing 1; errors: invalid e-mail (cse line 3), damaged line (cse line 4), duplicate 192311001 (events merged), it.txt missing. Student 192311001 has Dance;Singing;Quiz in the master list.

Alternative (list search for duplicates): O(n^2) time versus O(n) for a set or dictionary; space O(n) for both. Measured: n = 2,000: 0.0091 s list and 0.00018 s set; n = 20,000: 0.9046 s list and 0.00167 s set. When n grew 10 times, the list time grew about 100 times.
