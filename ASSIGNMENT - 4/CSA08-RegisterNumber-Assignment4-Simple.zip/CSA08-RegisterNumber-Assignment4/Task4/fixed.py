# Task 4.3 - repaired program: append mode, newlines, with, error log
def save_returns(books):
    with open("returns.log", "a", encoding="utf-8") as log:
        for b in books:
            log.write(str(b) + "\n")


def process(day_file):
    try:
        with open(day_file, "r", encoding="utf-8") as f:
            books = [line.strip() for line in f if line.strip() != ""]
        save_returns(books)
    except FileNotFoundError:
        with open("errors.log", "a", encoding="utf-8") as err:
            err.write("missing file: " + day_file + "\n")


import os
for name in ["returns.log", "errors.log"]:
    if os.path.exists(name):
        os.remove(name)
for d in ["day1.txt", "day2.txt", "day9.txt", "day3.txt"]:
    process(d)
print(open("returns.log").read())
print("errors.log:", open("errors.log").read())
