# Task 4 - original buggy program and a test that shows the defects
def save_returns(books):
    log = open("returns.log", "w")
    for b in books:
        log.write(b)
    log.close()

def process(day_file):
    try:
        books = open(day_file).read().split("\n")
        save_returns(books)
    except FileNotFoundError:
        print("missing")


open("day1.txt", "w").write("Python\nJava\n")
open("day2.txt", "w").write("Maths\nPhysics\n")
open("day3.txt", "w").write("Chemistry\nBiology\n")
for d in ["day1.txt", "day2.txt", "day3.txt", "day9.txt"]:
    process(d)
print("log content:", repr(open("returns.log").read()))
print("-> only day 3 is left, and the titles are joined together")
try:
    save_returns(["Maths", 101])
except TypeError as e:
    print("-> write() error:", e, "(close() never ran, nothing saved about the error)")
