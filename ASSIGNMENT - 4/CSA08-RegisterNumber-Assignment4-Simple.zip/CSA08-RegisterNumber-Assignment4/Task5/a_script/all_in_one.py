# (a) everything in one script
import os

def read_records(folder):
    records = []
    for name in sorted(os.listdir(folder)):
        with open(os.path.join(folder, name)) as f:
            for line in f:
                parts = line.strip().split(",")
                if len(parts) == 3 and parts[2] in ("P", "A"):
                    records.append(parts)
    return records

def percentages(records):
    p, t = {}, {}
    for reg, date, status in records:
        t[reg] = t.get(reg, 0) + 1
        if status == "P":
            p[reg] = p.get(reg, 0) + 1
    return {reg: round(100 * p.get(reg, 0) / t[reg], 1) for reg in t}

def absent_three(records):                       # NEW report
    streak, result = {}, set()
    for reg, date, status in sorted(records):
        streak[reg] = streak.get(reg, 0) + 1 if status == "A" else 0
        if streak[reg] >= 3:
            result.add(reg)
    return sorted(result)

def write_report(data, filename):
    with open(filename, "w") as out:
        for key in data:
            out.write(str(key) + " " + str(data[key]) + "\n")

if __name__ == "__main__":
    records = read_records("../data")
    print(percentages(records))
    print("absent 3 days:", absent_three(records))
