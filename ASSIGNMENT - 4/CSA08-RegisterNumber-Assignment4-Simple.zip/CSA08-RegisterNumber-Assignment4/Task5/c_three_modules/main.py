import reader, stats, report
records = reader.read_records("../data")
report.show("percentages:", stats.percentages(records))
report.show("absent 3 days:", stats.absent_three(records))
