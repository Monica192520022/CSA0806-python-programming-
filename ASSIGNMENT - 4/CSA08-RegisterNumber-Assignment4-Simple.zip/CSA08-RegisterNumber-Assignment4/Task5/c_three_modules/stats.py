def percentages(records):
    p, t = {}, {}
    for reg, date, status in records:
        t[reg] = t.get(reg, 0) + 1
        if status == "P":
            p[reg] = p.get(reg, 0) + 1
    return {reg: round(100 * p.get(reg, 0) / t[reg], 1) for reg in t}

def absent_three(records):                       # NEW report
    streak, result = {}, set()
    for reg, date, status in sorted(records):
        streak[reg] = streak.get(reg, 0) + 1 if status == "A" else 0
        if streak[reg] >= 3:
            result.add(reg)
    return sorted(result)
