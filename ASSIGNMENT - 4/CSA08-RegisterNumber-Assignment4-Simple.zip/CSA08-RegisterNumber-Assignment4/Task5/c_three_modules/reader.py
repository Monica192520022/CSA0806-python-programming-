import os

def read_records(folder):
    records = []
    for name in sorted(os.listdir(folder)):
        with open(os.path.join(folder, name)) as f:
            for line in f:
                parts = line.strip().split(",")
                if len(parts) == 3 and parts[2] in ("P", "A"):
                    records.append(parts)
    return records
