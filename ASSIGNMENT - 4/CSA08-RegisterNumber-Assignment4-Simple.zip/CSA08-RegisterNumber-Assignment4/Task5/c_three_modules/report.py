def show(title, data):
    print(title, data)
