"""attendance package"""
