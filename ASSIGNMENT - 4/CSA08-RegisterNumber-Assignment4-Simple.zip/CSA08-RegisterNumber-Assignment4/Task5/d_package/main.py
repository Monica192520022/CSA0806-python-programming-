import attendance.reader                      # style 1: full name
from attendance import stats                  # style 2: sub-module
from attendance.report import show            # style 3: one function

records = attendance.reader.read_records("../data")
show("percentages:", stats.percentages(records))
show("absent 3 days:", stats.absent_three(records))
