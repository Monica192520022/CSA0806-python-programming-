import mylib
records = mylib.read_records("../data")
print(mylib.percentages(records))
print("absent 3 days:", mylib.absent_three(records))
