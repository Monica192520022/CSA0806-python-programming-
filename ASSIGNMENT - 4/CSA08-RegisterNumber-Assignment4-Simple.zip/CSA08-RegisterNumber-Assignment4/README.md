# CSA08 Assignment 4 (CO4) - Files, Exceptions, Modules and Packages

Name: ____________   Register number: ____________
Python version: 3.12   Libraries: none (standard library only)
Answers and explanations: REPORT.md

## How to run (open the terminal inside the folder)

| Task | Folder | Command | Result |
| --- | --- | --- | --- |
| 1 | Task1 | python original.py | wrong total 1250 (bad script) |
| 1.2 | Task1 | python repaired.py | correct total 4941.50 and rejected lines |
| 1 alt | Task1 | python alt_readall.py | memory: line by line vs readlines() |
| 2 | Task2 | python attendance.py | percentages, below 75%, damaged log |
| 3 | Task3 | python complete_code.py | (1, 1, [(3, 'expected 3 fields, found 2'), (4, "invalid status 'L'")]) |
| 3 | Task3 | python try_statement.py | try/except/else/finally, raise from, misuse |
| 4 | Task4 | python buggy.py then python fixed.py | defects shown, then repaired |
| 5 | Task5/a_script | python all_in_one.py | one script |
| 5 | Task5/b_module | python main.py | module + main |
| 5 | Task5/c_three_modules | python main.py | three modules |
| 5 | Task5/d_package | python main.py | package |
| 6 | Task6 | python main.py | master list, event files, summary, errors.log |
| 6 alt | Task6 | python alt_duplicates.py | list search vs set |

Each task folder has an output.txt saved from my run. Add your own screenshots before uploading.

## Commits (at least one per task)
    git add Task1 && git commit -m "Task 1"
    (repeat for Task2 ... Task6, then README.md and REPORT.md)
